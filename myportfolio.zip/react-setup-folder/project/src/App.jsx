import React from 'react';
import { Heart } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl p-12 max-w-md w-full text-center transform hover:scale-105 transition-all duration-300">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-800 mb-4">
            Hello, World! 👋
          </h1>
          <p className="text-lg text-gray-600 leading-relaxed">
            Welcome to your first React application
          </p>
        </div>
        
        <div className="bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg p-6 mb-8">
          <p className="text-white font-medium">
            This is a beautiful React JSX component
          </p>
        </div>
        
        <div className="flex items-center justify-center gap-2 text-gray-500">
          <span>Made with</span>
          <Heart className="w-5 h-5 text-red-500 animate-pulse" />
          <span>and React</span>
        </div>
      </div>
    </div>
  );
}

export default App;